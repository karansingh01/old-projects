package del1;

import java.util.ArrayList;
import java.util.List;

public class VaccineTrial {

	// Add any needed fields here

	VaccineTrialVolunteer v;
	/**
	 * Adds a new VaccineTrialVolunteer to the trial
	 * 
	 * @param id      The id of the volunteer
	 * 
	 * @param placebo Whether the volunteer was given a placebo, or the actual
	 *                vaccine
	 */

	private List<VaccineTrialVolunteer> volunteer = new ArrayList<VaccineTrialVolunteer>();

	public void addVolunteer(String id, boolean placebo) {
		volunteer.add(new VaccineTrialVolunteer(id, placebo));

	}

	/**
	 * Returns whether the vaccine's effectiveness rate is higher than the provided
	 * limit. The effectiveness of the vaccine is calculated as follows:
	 * 
	 * 1- (number of people that received the vaccine and got sick/ number of people
	 * that got sick)
	 * 
	 * If there is no sick people, the vaccine is not effective
	 * 
	 * @param limit A limit to compare against
	 * 
	 * @throws IllegalArgumentException If limit is not between (including) 0 and 1.
	 * 
	 * @return Whether the vaccine effectiveness rate is higher than the limit
	 */
	public boolean isMoreEffectiveThanLimit(double limit) {
		double vaccineS = 0;
		double sick = 0;

		for (VaccineTrialVolunteer v : volunteer) {
			if (v.isPlacebo() == false && v.gotSick()) {
				vaccineS++;
			}
			if (v.gotSick()) {
				sick++;
			}
		}

		double ans = 1 - ((vaccineS / sick));

		if (ans > 1.0 || 0.0 > ans) {
			throw new IllegalArgumentException("must be between 0 and 1");
		}

		if (sick == 0) {
			return false;
		}
		if (ans > limit) {
			return true;
		}

		return false;

	}

	/**
	 * Updates the sick state of a VaccineTrialVolunteer
	 * 
	 * @param id The id of the volunteer to set sick.
	 * @throws IllegalArgumentException if there is no volunteer with the given id
	 */
	public void setSick(String id) {

//		if (!volunteer.contains(v.getId() == id)) {
//			throw new IllegalArgumentException("no volunteer with given id");
//		}

		for (VaccineTrialVolunteer v : volunteer) {
			if (v.getId() == id) {
				v.setGotSick(true);
			}

		}

	}

	/**
	 * Get's the volunteer with the given ID
	 * 
	 * @param id The id of the volunteer to set sick.
	 * 
	 * @return The vaccine trial volunteer with the given ID. If the ID is not valid
	 *         for any volunteer, return null
	 */
	public VaccineTrialVolunteer getVolunteer(String id) {
		return volunteer.stream().filter(i -> i.getId().equals(id)).findAny().orElse(null);
	}

	public static void main(String[] args) {
		VaccineTrial trial = new VaccineTrial();
		trial.addVolunteer("1", false);
		trial.addVolunteer("2", false);
		trial.addVolunteer("3", true);
		trial.addVolunteer("4", true);
		trial.setSick("4");
		// Should now be true
		System.out.println(trial.isMoreEffectiveThanLimit(0.5));

	}
}
