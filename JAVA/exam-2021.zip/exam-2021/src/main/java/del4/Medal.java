package del4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Medal {

	private String metal;
	public static List<String> validMetals = Arrays.asList("Gold", "Silver", "Bronze");

	public Medal(String metal) {
		if (!validMetals.contains(metal)) {
			throw new IllegalArgumentException("Invalid medal");
		}
		this.metal = metal;
	}

	public String getMetal() {
		return metal;
	}

	public int getGold() {
		List<String> golds = new ArrayList<String>();
		if (getMetal() == "gold") {
			golds.add(metal);
		}
		return golds.size();
	}

	public int getSilver() {
		List<String> silver = new ArrayList<String>();
		if (getMetal() == "silver") {
			silver.add(metal);
		}
		return silver.size();
	}

	public int getBronze() {
		List<String> bronze = new ArrayList<String>();
		if (getMetal() == "bronze") {
			bronze.add(metal);
		}
		return bronze.size();
	}

}