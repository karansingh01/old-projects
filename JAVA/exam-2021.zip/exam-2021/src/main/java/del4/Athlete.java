package del4;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Athlete {

	private List<Medal> medals = new ArrayList<Medal>();
	private String country;
	private String name;

	Medal medal;

	public Athlete(String country, String name, List<Medal> medals) {
		this.name = name;
		this.country = country;
		this.medals = new ArrayList<>(medals);
	}

	public List<Medal> getMedals() {
		return new ArrayList<>(medals);
	}

	public List<Medal> getNewMedals(String metal) {

		return medals.stream().filter(p -> p.getMetal().equals(metal)).collect(Collectors.toList());

	}

	public String getCountry() {
		return country;
	}

	public String getName() {
		return name;
	}

}