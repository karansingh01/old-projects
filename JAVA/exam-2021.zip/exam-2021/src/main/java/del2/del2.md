# Del 2- Innkapsling og Objektstrukturer

Fyll inn set og get-metodene i [Person](Person.java)-klassen. 
Du skal gjøre dette uten å endre kode i [Address](Address.java)-klassen. 
