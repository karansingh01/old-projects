package del3;

public class SomeServiceImpl implements SomeService {

	@Override
	public String getAMagicString() {
		return "magic";
	}

	@Override
	public int getAMagicNumber() {
		return 42;
	}

}
