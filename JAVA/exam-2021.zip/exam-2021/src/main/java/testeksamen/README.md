# Meeting Room 

Fyll ut klassen [MeetingRoom](MeetingRoom.java) og alle metodene i denne. 