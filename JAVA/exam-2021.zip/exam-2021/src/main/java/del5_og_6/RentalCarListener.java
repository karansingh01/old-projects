package del5_og_6;

import java.util.ArrayList;
import java.util.List;

/* RentalCar listeners listens to changes in Status for all userNames.*/
public class RentalCarListener implements StatusListener {

	// TODO - Add any needed fields here

	private String username;
	private String oldStatus;
	private String newStatus;

	LoyaltyUser user;

	private List<String> usersGold = new ArrayList<String>();

	@Override
	/**
	 * Method that should be called when a given userName has updated its status.
	 */
	public void statusChanged(String username, String oldStatus, String newStatus) {
		this.username = username;
		this.newStatus = newStatus;
		this.oldStatus = oldStatus;

		if (user.getStatus() == "Gold") {
			usersGold.add(user.getUsername());
		}

		// user.addListener(this, newStatus);

	}

	/**
	 * Get's the discount of a user. Should be a 100 if the user currently has Gold
	 * status, otherwise should be 0.
	 * 
	 * @param username The username of the user
	 * 
	 * @return The discount the user qualifies for.
	 */
	public int getDiscount(String username) {
		if (usersGold.contains(username)) {
			if (user.getPoints() > 5000 && user.getPoints() < 10000) {
				return 100;
			}
		}
		return 0;
	}

	public static void main(String[] args) {
		var a = new LoyaltyUser("ola");

		System.out.println(a.getStatus());
		System.out.println(a.getPoints());
		a.addPoints(5500);
		System.out.println(a.getPoints());
		System.out.println(a.getStatus());
	}

}
