package inheritance;

public class CargoCar extends TrainCar {
	private int cargoWeight;

	public CargoCar(int deadWeight, int cargoWeight) {
		super(deadWeight);
		this.cargoWeight = cargoWeight;
	}

	public void setCargoWeight(int weight) {
		this.cargoWeight = weight;
	}

	public int getCargoWeight() {
		return this.cargoWeight;
	}

	@Override
	public int getTotalWeight() {
		return this.getDeadWeight() + this.cargoWeight;
	}
}
