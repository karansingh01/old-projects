const btn = document.querySelector("#btn")


btn.onclick = function(){
btn.innerHTML = "Du trykket på meg";
}
