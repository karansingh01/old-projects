var btn = document.getElementById("btn");
var innhold = document.getElementById("innhold");



btn.onclick = function() {
innhold.innerHTML = '<img src="../../Jugad/bmw1.jpeg">';
}
