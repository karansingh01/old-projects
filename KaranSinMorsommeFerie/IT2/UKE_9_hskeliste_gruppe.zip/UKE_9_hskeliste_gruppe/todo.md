#todo.

- Som bruker ønsker jeg å ha en mer Farger slik at siden blir mer inntersant brukergrensesnitt.


- SOM Bruker ønsker jeg en mer innteresant overskrift slik at netsiden blir mer brukervennlig.


- Er Lett å bruke og er oversiktlig, BRA at man kan fjerne en ting, men også alt sammen
