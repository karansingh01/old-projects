package patterns.delegation.office;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Printer {

	public Map<Employee, ArrayList<String>> oversikt = new HashMap<Employee, ArrayList<String>>();

	public void printDocument(String document, Employee employee) {
		ArrayList<String> ny = new ArrayList<String>();
		if (oversikt.containsKey(employee)) {
			ny = oversikt.get(employee);
		}
		ny.add(document);
		oversikt.put(employee, ny);
	}

	public List<String> getPrintHistory(Employee employee) {
		if (oversikt.containsKey(employee)) {
			return new ArrayList<>(oversikt.get(employee));
		}
		return new ArrayList<String>();
	}

}
