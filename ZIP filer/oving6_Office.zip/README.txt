Kildekode for øving 6


Delegerings teknikkken:
Det er en måte at et obkjekt bruker interne objeker for 
å utføre arbeid/logikk, Altså delegerer oppgaven til et intern
objekt. Det er ofte en 1-n relasjon mellom elegerende og delegaten.




Observatør- Observert- teknikken:
Dette brukes når man skal se om et objekt har korrekt tilstand, 
ved å alltid være oppdatert når det skjer en endring.

Observert rollen: registrer  observatører.
. endrer sin egen tilstand og sier ifra om det til observatørene.

Observatør rollen:
- ta imot beskjed om tilstandsendringene i objektene det observerer