package patterns.delegation.office;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Office {

	private String Manager = null;
	// private String Clerk = null;
	private List<Clerck> clercks = new ArrayList<Clerck>();

	HashMap<String, String> clercks2 = new HashMap<String, String>();

	interface Employee {

	}

}
