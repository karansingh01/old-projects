package patterns.delegation.office;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.function.BinaryOperator;

public class Manager implements Employee {

	Collection<Employee> undersatte = new ArrayList<Employee>();
	int tasksDone = 0;
	int neste = 0;

	Manager(Collection<Employee> employees) {
		if (employees.size() == 0) {
			throw new IllegalArgumentException("Ikke noen employees");
		}
	}

	public void add(Employee e) {
		undersatte.add(e);
		undersatte.add(e);
		undersatte.add(e);
	}

	@Override
	public int getResourceCount() {
		int i = 1;
		for (Employee e : undersatte) {
			i += e.getResourceCount();
		}
		return i;
	}

	@Override
	public double doCalculations(BinaryOperator<Double> operation, double value1, double value2) {
		tasksDone++;
		if (neste + 1 < undersatte.size()) {
			neste++;
		} else {
			neste = 0;
		}
		return ((List<Employee>) undersatte).get(neste).doCalculations(operation, value1, value2);
	}

	@Override
	public void printDocument(String document) {
		tasksDone++;
		if (neste + 1 < undersatte.size()) {
			neste++;
		}
		((List<Employee>) undersatte).get(neste).printDocument(document);
	}

	@Override
	public int getTaskCount() {
		return this.tasksDone;
	}

	@Override
	public String toString() {
		return ": " + this.tasksDone + ":" + undersatte.size();
	}

	public static void main(String[] args) {

		var printer = new Printer();
		var clerk = new Clerk(printer);
		var clerk2 = new Clerk(printer);
		var clerk3 = new Clerk(printer);
		var manager = new Manager(Arrays.asList(clerk, clerk2, clerk3));
		System.out.println(clerk.getTaskCount());
		System.out.println(manager.getResourceCount());
		System.out.println("------");
		System.out.println(manager.getTaskCount());
	}
}
