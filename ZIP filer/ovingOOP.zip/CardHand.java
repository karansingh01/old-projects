package objectstructures;

import java.util.ArrayList;

public class CardHand {
	public ArrayList<Card> hand;

	public CardHand() {
		hand = new ArrayList<>();
	}

	public void addCard(Card card) {
		hand.add(card);
	}

	public ArrayList<Card> play(int n) {
		hand.remove(n);
		return hand;
	}

	public int getCardCount() {
		return hand.size();
	}

	public Card getCard(int n) {
		if (n < hand.size()) {
			char x = hand.get(n).toString().charAt(0);
			Card a = new Card(x, Integer.valueOf(hand.get(n).toString().substring(1)));
			return a;
		} else {
			throw new IllegalArgumentException("Ikke et gydig kort");
		}
	}

	public static void main(String[] args) {

	}
}
