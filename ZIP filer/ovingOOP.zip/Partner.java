package objectstructures;

public class Partner {

	private String name;
	private Partner partner;

	public Partner(String name) {
		this.name = name;
	}

	public void setPartner(Partner partner) {
		if (this.partner == partner) {
			return;
		}

		Partner oldPart = this.partner;
		this.partner = partner;

		if (oldPart != null && oldPart.getPartner() == this) {
			oldPart.setPartner(null);
		}

		if (this.partner != null) {
			this.partner.setPartner(this);
		}
	}

	String getName() {
		return name;
	}

	Partner getPartner() {
		return partner;
	}

	@Override
	public String toString() {
		String nyVerdi;
		if (partner != null) {
			nyVerdi = name + " : PARTNER : " + partner.name;
		} else {
			nyVerdi = name;
		}
		return nyVerdi;

	}

	public static void main(String[] args) {
		var pers1 = new Partner("Ole");
		var pers2 = new Partner("Tobias");
		var pers3 = new Partner("Vibekke");
		pers1.setPartner(pers3);
		System.out.println(pers1);
		System.out.println(pers2);
		System.out.println(pers3);
	}

}
