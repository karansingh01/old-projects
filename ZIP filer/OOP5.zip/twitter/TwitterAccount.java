package interfaces.twitter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

public class TwitterAccount {

	private final String userName;

	public Collection<TwitterAccount> follows = new ArrayList<TwitterAccount>();
	public Collection<TwitterAccount> followers = new ArrayList<TwitterAccount>();

	private List<Tweet> tweets = new ArrayList<Tweet>();

	public TwitterAccount(String username) {
		this.userName = username;
	}

	@Override
	public String toString() {
		return "[Username: " + getUserName() + " - " + getTweetCount() + " tweets]";
	}

	public String getUserName() {
		return userName;
	}

	public void follow(TwitterAccount otherUser) {
		if (this == otherUser) {
			throw new IllegalStateException("You cannot follow yourself.");
		}
		if (!follows.contains(otherUser)) {
			follows.add(otherUser);
			otherUser.followers.add(this);
		}
	}

	public void unfollow(TwitterAccount otherUser) {
		if (follows.contains(otherUser)) {
			follows.remove(otherUser);
			otherUser.followers.remove(this);
		}
	}

	public boolean isFollowing(TwitterAccount otherUser) {
		return follows.contains(otherUser);
	}

	public boolean isFollowedBy(TwitterAccount otherUser) {
		return followers.contains(otherUser);
	}

	public void tweet(String text) {
		tweets.add(new Tweet(this, text));
	}

	public void retweet(Tweet tweet) {
		tweets.add(new Tweet(this, tweet));
	}

	public Tweet getTweet(int i) {
		return tweets.get(tweets.size() - i);
	}

	public int getTweetCount() {
		return tweets.size();
	}

	public int getRetweetCount() {
		int count = 0;
		for (Tweet tweet : tweets) {
			count += tweet.getRetweetCount();
		}
		return count;
	}

	public ArrayList<TwitterAccount> getFollowers(Comparator<TwitterAccount> FollowersCount) {
		if (FollowersCount == null) {
			return (ArrayList<TwitterAccount>) this.followers;
		} else {
			ArrayList<TwitterAccount> listen = (ArrayList<TwitterAccount>) this.followers;
			return listen;

			// return Collections.sort(followers, new userNameComparator());
		}
	}

	public static void main(String[] args) {
		var user1 = new TwitterAccount("Ola");
		var user2 = new TwitterAccount("Vibekke");
		var user3 = new TwitterAccount("Roar");

		user1.follow(user2);
		user1.follow(user3);
		user2.follow(user1);
		user2.tweet("heihehiei");
		user2.tweet("skkkrt");
		user3.retweet(user2.getTweet(1));
		System.out.println(user1);
		System.out.println(user2);
		System.out.println(user3);

	}

}
