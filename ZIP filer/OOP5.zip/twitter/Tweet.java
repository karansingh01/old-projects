package interfaces.twitter;

public class Tweet {

	public int retweets = 0;
	public String text;
	private TwitterAccount owner;
	private Tweet originalTweet;

	// Lsger en ny tweet
	public Tweet(TwitterAccount owner, String text) {
		this.owner = owner;
		this.text = text;
	}

	public void setRetweetCount() {
		retweets += 1;
	}

	public Tweet(TwitterAccount owner, Tweet tweet) {
		if (this.owner == owner) {
			throw new IllegalArgumentException("cant retweets your own");
		}

		this.owner = owner;

		if (tweet.getOriginalTweet() != null) {
			this.originalTweet = tweet.originalTweet;
			this.text = tweet.originalTweet.text;

		} else {
			this.originalTweet = tweet;
			this.text = tweet.text;
		}

		this.originalTweet.setRetweetCount();

	}

	public String getText() {
		return text;
	}

	public TwitterAccount getOwner() {
		return owner;

	}

	public Tweet getOriginalTweet() {
		return originalTweet;
	}

	public int getRetweetCount() {
		return retweets;
	}

}
