package interfaces.twitter;

import java.util.Comparator;

public class FollowersCountComparator implements Comparator<TwitterAccount> {
	// Sorterer twitteraccountene basert på antall følgere.
	// Accounten med flest følgere vil havne først.
	@Override
	public int compare(TwitterAccount a, TwitterAccount b) {
		return b.followers.size() - a.followers.size();
	}
}
