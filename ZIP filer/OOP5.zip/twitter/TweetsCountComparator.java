package interfaces.twitter;

import java.util.Comparator; // import the ArrayList class

public class TweetsCountComparator implements Comparator<TwitterAccount> {

	@Override
	public int compare(TwitterAccount a, TwitterAccount b) {
		return b.getTweetCount() - a.getTweetCount();
	}
}
